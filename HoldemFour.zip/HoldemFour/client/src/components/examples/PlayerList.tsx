import PlayerList from '../PlayerList';

export default function PlayerListExample() {
  // TODO: remove mock data when integrating real functionality
  const mockPlayers = [
    {
      id: '1',
      name: 'Alice Johnson',
      isConnected: true,
      hasCards: true,
      isReady: true
    },
    {
      id: '2', 
      name: 'Bob Smith',
      isConnected: true,
      hasCards: true,
      isReady: false
    },
    {
      id: '3',
      name: 'Charlie Brown',
      isConnected: false,
      hasCards: false,
      isReady: false
    },
    {
      id: '4',
      name: 'Diana Prince',
      isConnected: true,
      hasCards: false,
      isReady: true
    }
  ];

  return (
    <div className="p-6 bg-background min-h-screen">
      <PlayerList 
        players={mockPlayers}
        currentPlayer="1"
        roomCode="ABC123"
        className="max-w-sm mx-auto"
      />
    </div>
  );
}