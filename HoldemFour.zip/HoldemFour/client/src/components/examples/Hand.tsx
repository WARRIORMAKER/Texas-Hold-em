import Hand from '../Hand';

export default function HandExample() {
  const sampleHand = [
    { suit: 'hearts' as const, value: 'A' as const, id: '1' },
    { suit: 'spades' as const, value: 'K' as const, id: '2' },
    { suit: 'diamonds' as const, value: 'Q' as const, id: '3' },
    { suit: 'clubs' as const, value: 'J' as const, id: '4' }
  ];

  const partialHand = [
    { suit: 'hearts' as const, value: '10' as const, id: '5' },
    { suit: 'spades' as const, value: '9' as const, id: '6' }
  ];

  return (
    <div className="p-6 bg-poker-table min-h-screen space-y-8">
      <Hand 
        cards={sampleHand} 
        title="Your Hand" 
      />
      <Hand 
        cards={partialHand} 
        title="Dealing..." 
        isDealing={true}
      />
    </div>
  );
}