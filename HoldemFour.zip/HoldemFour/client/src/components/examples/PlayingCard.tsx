import PlayingCard from '../PlayingCard';

export default function PlayingCardExample() {
  return (
    <div className="p-6 bg-poker-table min-h-screen flex gap-4 flex-wrap items-center justify-center">
      <PlayingCard 
        card={{ suit: 'hearts', value: 'A', id: '1' }} 
        size="lg"
      />
      <PlayingCard 
        card={{ suit: 'spades', value: 'K', id: '2' }} 
        size="lg"
      />
      <PlayingCard 
        card={{ suit: 'diamonds', value: 'Q', id: '3' }} 
        size="lg"
      />
      <PlayingCard 
        card={{ suit: 'clubs', value: 'J', id: '4' }} 
        size="lg"
      />
      <PlayingCard 
        isBack={true} 
        size="lg"
      />
    </div>
  );
}