import { useState } from 'react';
import JoinScreen from '../JoinScreen';

export default function JoinScreenExample() {
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState('');

  const handleJoin = (playerName: string, roomCode: string) => {
    console.log('Join triggered:', { playerName, roomCode });
    setIsConnecting(true);
    setError('');
    
    // Simulate connection process
    setTimeout(() => {
      if (Math.random() > 0.3) {
        setIsConnecting(false);
        console.log('Successfully joined room');
      } else {
        setIsConnecting(false);
        setError('Room not found. Please check the room code and try again.');
      }
    }, 2000);
  };

  return (
    <JoinScreen 
      onJoin={handleJoin}
      isConnecting={isConnecting}
      error={error}
    />
  );
}