import { useState } from 'react';
import GameScreen from '../GameScreen';

export default function GameScreenExample() {
  const [isDealing, setIsDealing] = useState(false);
  const [playerHand, setPlayerHand] = useState([
    { suit: 'hearts' as const, value: 'A' as const, id: '1' },
    { suit: 'spades' as const, value: 'K' as const, id: '2' },
    { suit: 'diamonds' as const, value: 'Q' as const, id: '3' },
    { suit: 'clubs' as const, value: 'J' as const, id: '4' }
  ]);

  // TODO: remove mock functionality when integrating real backend
  const mockPlayers = [
    {
      id: '1',
      name: 'Alice Johnson', 
      isConnected: true,
      hasCards: true,
      isReady: true
    },
    {
      id: '2',
      name: 'Bob Smith',
      isConnected: true, 
      hasCards: true,
      isReady: false
    },
    {
      id: '3',
      name: 'Charlie Brown',
      isConnected: false,
      hasCards: false,
      isReady: false
    }
  ];

  const handleDealCards = () => {
    console.log('Deal cards triggered');
    setIsDealing(true);
    
    // Simulate dealing animation
    setTimeout(() => {
      setIsDealing(false);
      console.log('Cards dealt successfully');
    }, 2000);
  };

  const handleLeaveRoom = () => {
    console.log('Leave room triggered');
  };

  return (
    <GameScreen
      players={mockPlayers}
      currentPlayer="1"
      roomCode="ABC123"
      playerHand={playerHand}
      onDealCards={handleDealCards}
      onLeaveRoom={handleLeaveRoom}
      canDeal={true}
      isDealing={isDealing}
      connectionStatus="connected"
    />
  );
}