# Overview

This is a multiplayer 4-card Texas Hold'em poker game built with React (frontend), Express/Socket.IO (backend), and PostgreSQL (database). Players can create and join game rooms using unique 6-character codes to play poker in real-time with up to 6 players per room.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Framework**: shadcn/ui components built on Radix UI primitives with Tailwind CSS
- **State Management**: React hooks with Socket.IO for real-time communication
- **Routing**: wouter for lightweight client-side routing
- **Design System**: Dark-mode focused poker theme with gaming-inspired color palette (deep blue-gray backgrounds, poker green accents)

## Backend Architecture
- **Server**: Express.js with Socket.IO for WebSocket communication
- **Game Logic**: Custom PokerGameManager class handling room creation, card dealing, player actions, and game state
- **Storage**: Abstracted storage interface with in-memory implementation (ready for database integration)
- **Session Management**: Socket-based player sessions with reconnection support

## Data Storage
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**:
  - Users table for authentication
  - Rooms table storing game state, pot, betting rounds, and card data as JSON
  - Players table tracking chips, hands, positions, and connection status
- **Real-time Data**: Game state synchronized via Socket.IO events between clients

## Game Logic Design
- **Card System**: Standard 52-card deck with shuffle algorithms
- **Room Management**: 6-character alphanumeric room codes for easy sharing
- **Player States**: Connected/disconnected, ready status, folded status, betting actions
- **Game Phases**: Waiting → Dealing → Betting → Showdown → Finished
- **Betting Rounds**: Pre-flop → Flop → Turn → River → Showdown

## Component Architecture
- **Modular Components**: Reusable game components (PlayingCard, Hand, BettingControls, PlayerList)
- **Socket Provider**: Centralized WebSocket connection management with React Context
- **Game State Management**: Separation of UI state and game logic with clear data flow

# External Dependencies

## Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, TypeScript, Vite for development and build
- **UI Libraries**: Radix UI components, Tailwind CSS, Lucide React icons, shadcn/ui design system
- **Real-time Communication**: Socket.IO client and server for WebSocket connections

## Database & ORM
- **Database**: Neon PostgreSQL (serverless PostgreSQL hosting)
- **ORM**: Drizzle ORM with Drizzle Kit for migrations and schema management
- **Validation**: Zod for runtime type checking and schema validation

## Development Tools
- **Build Tools**: esbuild for server bundling, PostCSS for CSS processing
- **Development**: tsx for TypeScript execution, Replit integration plugins
- **Fonts**: Google Fonts integration (Inter, DM Sans, Fira Code, Geist Mono)

## Session & State Management
- **Session Storage**: connect-pg-simple for PostgreSQL-backed session storage
- **Client State**: TanStack React Query for server state management and caching
- **Form Handling**: React Hook Form with Hookform resolvers for form validation

The application uses environment variables for database configuration and is designed to work seamlessly in both development and production environments with proper error handling and logging.