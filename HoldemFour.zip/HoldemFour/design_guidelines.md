# Design Guidelines for Multiplayer 4-Card Texas Hold'em Poker Game

## Design Approach
**Selected Approach**: Reference-Based (Gaming/Entertainment)
**Primary References**: PokerStars, 888poker online interfaces
**Justification**: Gaming applications require immersive visual design that builds excitement while maintaining clarity for gameplay mechanics.

## Core Design Elements

### A. Color Palette
**Dark Mode Primary** (as specified by user):
- Background: 220 15% 8% (deep dark blue-gray)
- Surface: 220 15% 12% (slightly lighter surface)
- Text Primary: 0 0% 95% (near white)
- Text Secondary: 0 0% 70% (muted gray)

**Accent Colors**:
- Primary (Poker Green): 140 60% 35% (classic poker table green)
- Success: 120 70% 45% (dealing/join confirmations)
- Warning: 45 90% 55% (room full, connection issues)
- Card Suits: Traditional red (0 80% 50%) and black (0 0% 10%)

### B. Typography
**Font Stack**: 'Inter', 'Segoe UI', system fonts
- Headers: 600 weight, 1.5rem-2rem sizes
- Body: 400 weight, 1rem base
- Card values: 700 weight, monospace for alignment
- Room codes: Monospace, uppercase styling

### C. Layout System
**Spacing Units**: Tailwind 2, 4, 6, 8, 12, 16 units
- Consistent 4-unit base rhythm
- Card spacing: 2-unit gaps
- Section padding: 8-unit standard
- Button margins: 4-unit spacing

### D. Component Library

**Navigation**: Minimal header with room code display and player count

**Forms**: 
- Join screen: Centered card-style form with poker-themed styling
- Input fields: Dark backgrounds with green accent borders on focus
- Buttons: Rounded, poker green primary with subtle hover states

**Game Interface**:
- Player list: Vertical sidebar with avatar placeholders and status indicators
- Card display: Realistic card representations with suit symbols
- Deal button: Prominent, center-positioned action button
- Hand area: Horizontal card layout with subtle shadows

**Cards**:
- Traditional playing card design with rounded corners
- Clear suit symbols and values
- Subtle drop shadows for depth
- Hover states for interactivity

**Status Indicators**:
- Connection status: Subtle dot indicators
- Player ready states: Color-coded backgrounds
- Room status: Badge-style indicators

### E. Animations
**Minimal Animation Strategy**:
- Card dealing: Subtle slide-in from deck position
- Player join/leave: Gentle fade transitions
- Button interactions: Micro-feedback on click
- Connection status: Pulse for disconnection warnings

**Avoid**: Distracting card flip animations, excessive transitions

## Gaming-Specific Design Considerations

**Poker Table Aesthetic**:
- Felt-inspired background textures (very subtle)
- Traditional card styling with clear readability
- Professional color scheme avoiding garish gaming clichés

**User Experience Priority**:
- Instant visual feedback for all actions
- Clear indication of whose turn/action is next
- Obvious connection status for all players
- Mobile-responsive design for tablet/phone play

**Accessibility**:
- High contrast for card readability
- Large touch targets for mobile play
- Clear focus indicators for keyboard navigation
- Screen reader friendly card announcements

## Layout Structure
1. **Join Screen**: Centered form with poker theme
2. **Game Screen**: Sidebar players list + main game area
3. **Hand Display**: Bottom-positioned personal cards
4. **Action Area**: Central deal button and game status

This design creates an authentic poker atmosphere while maintaining the clean, functional interface required for real-time multiplayer gameplay.